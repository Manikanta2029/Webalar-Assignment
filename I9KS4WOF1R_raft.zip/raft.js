const form = document.querySelector('form');
const firstname = document.querySelector('fname');
const lastname = document.querySelector('lname');
const phone = document.querySelector('phone');
const email = document.querySelector('email');

function sendEmail() {
    const bodyMessage = `Full Name ${firstname.vallue}<br> Last Name: ${email.value}<br> Phone Number: ${phone.value}<br> Message: ${mess.value}`
    Email.send({
        Host: "smtp.elasticemail.com",
        Firstname: "username",
        Password: "password",
        To: 'them@website.com',
        From: "you@isp.com",
        Subject: "This is the subject",
        Body: "And this is the body"
    }).then(
        message => alert(message)
    );
}

function checkInput() {
    const items = document.querySelectorAll(".item");

    for (const item of items) {
        if (item.value == "") {
            item.classList.add("error");
            item.parentElement.classList.add("Error")
        }
    }
}
form.addEventListener("Send consulation", (e) => {
    e.preventDefault();

    sendEmail();
})